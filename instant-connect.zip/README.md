This is a repo for a chrome extension : [LPU - Instant Connect]( https://chromewebstore.google.com/detail/lpu-instant-connect/pkjmmknbbgomeoihdjbakahebhkkepgg).
This extension is meant to reduce the amount of time required for login from the lpu wifi.
